export const MediData = [{
    "id": "1",
    "product": "citrizen",
    "image": "/assets/Medicines/citrizen.jpg",
    "price": "Rs.50.00",
    "category": "Medicines"
},
{
    "id": "2",
    "product": "paracetamol",
    "image": "/assets/Medicines/paracetamol.jpg",
    "price": "Rs.10.00",
    "category": "Medicines"
    
},
{
    "id": "3",
    "product": "Cough Syrup",
    "image": "/assets/Medicines/syrup1.jpg",
    "price": "Rs.60.00",
    "category": "Medicines"
    
},
{
    "id": "4",
    "product": "Suncof Ht",
    "image": "/assets/Medicines/syrup2.jpg",
    "price": "Rs.75.00",
    "category": "Medicines"
    
}
]