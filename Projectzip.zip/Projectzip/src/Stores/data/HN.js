export const HNData = [{
    "id": "1",
    "product": "Horlicks",
    "image": "/assets/HD&NS/Horlicks.jpg",
    "price": "Rs.150.00",
    "category": "Health Drink & Nutritional Supplements"
},
{
    "id": "2",
    "product": "Protinex",
    "image": "/assets/HD&NS/Protinex.jpg",
    "price": "Rs.200.00",
    "category": "Health Drinks & Nutritional Supplements"
    
}
]