export const FSData = [{
    "id": "1",
    "product": "Mask",
    "image": "/assets/F&S/mask.jpg",
    "price": "Rs.15.00",
    "category": "FaceMask & Santizers"
},
{
    "id": "2",
    "product": "Sanitizer",
    "image": "/assets/F&S/sanitizer.jpg",
    "price": "Rs.100.00",
    "category": "FaceMask & Santizers"
    
},
{
    "id": "3",
    "product": "N95 Mask",
    "image": "/assets/F&S/N95.jpg",
    "price": "Rs.95.00",
    "category": "FaceMask & Santizers"
    
},
{
    "id": "4",
    "product": "Sanitizers",
    "image": "/assets/F&S/sanitizer2.jpg",
    "price": "Rs.200.00",
    "category": "FaceMask & Santizers"
    
}
]