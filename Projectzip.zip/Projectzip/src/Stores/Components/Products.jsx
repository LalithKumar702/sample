import React from 'react'
import FS from './FS'
import Medi from './Medi'


const Products = () => {
  return (
    <div>
      <FS/>
      <Medi/>
    </div>
  )
}

export default Products
