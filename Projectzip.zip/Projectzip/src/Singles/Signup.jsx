import React, { useState } from "react";
import { Link } from 'react-router-dom';
import "../App.css";

function Signup() {
    const [isSubmitted, setIsSubmitted] = useState(false);
    
    const handleSubmit=()=>{
        setIsSubmitted(true);
    }

    const renderForm = (
        <div className="form">
             <form onSubmit={handleSubmit}>
          <div className="input-container">
            <label>Email ID</label>
            <input type="email" name="email" required />
          </div>
          <div className="input-container">
            <label>First Name</label>
            <input type="text" name="firstName" required />
          </div>
          <div className="input-container">
            <label>Last Name</label>
            <input type="text" name="lastName" required />
          </div>
          <div className="input-container">
            <label>Phone Number</label>
            <input type="tel" name="phoneNumber" required />
          </div>
          <div className="input-container">
            <label>Password</label>
            <input type="password" name="password" required />
          </div>
          <div className="button-container">
            <input type="submit"/>
          </div>
        </form>
        </div>
    );

  return (
    <>
    <div className="Login">
    <div className="login-form">
    <Link to="/">Back to Home Page</Link>
    <br/><br/>
      <div className="title">Sign In</div>
      {isSubmitted ? (
        <div>User is successfully Signed in
            <div className="button-container">
          <Link to="/Login" className="btn">Return To Login Page</Link>
        </div>
        </div>
        
      ) : (
        <div>
          {renderForm}
          <div className="button-container">
          <Link to="/Login" className="btn">Login</Link>
        </div>
          
        </div>
      )}
    </div>
  </div>
    </>
  );
}

export default Signup;
